//AUTHOR: Robert Allen
//COURSE: CPT 187
//Purpose: to help a local Video Store for DVDs that will keep track of the inventory
//DATE: February 12 2020
package edu.cpt187.allen.program5;

import java.util.Scanner;

public class MainClass 
{
	public static final String[] MAIN_MENU_OPTIONS = {"Quit","Load Product Catalog"};
	public static final String[] SEARCH_MENU_OPTIONS = {"Return to Main Menu","Search for an ID"};

	
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);

		//local variables 
		String userName = "";
		char menuSelection = ' ';
		
		//Create instance from the supportive class 
		ProductInventory currentInventory = new ProductInventory();
		
		//DISPLAY Welcome Banner
		displayWelcomeBanner();
		

		//gets and displays userName
		userName = getUserName(input);

		//Prime read of MenuSelection
		menuSelection = validateMenuSelection(input);
		
		//run-while
		while(menuSelection != 'Q')
		{
			currentInventory.setProductArrays(getFileName(input));
			
			//run if else
			if(currentInventory.getRecordCount() <= 0)
			{
				displayFileError();
			}//end of if
			else
			{
				menuSelection = validateSearchSelection(input);
				
				while(menuSelection != 'B')
				{
					currentInventory.setSearchIndex(validateSearchID(input));
					if(currentInventory.getSearchedIndex() < 0)
					{
						displaySearchResult();
					}
					else
					{
						displaySearchResult(currentInventory.getSearchedIndex(),currentInventory.getProductID(), currentInventory.getProductTitle(), currentInventory.getProductPrice());
					}
					menuSelection = validateSearchSelection(input);
				}//end of while
				
				if(currentInventory.getSearchCount() > 0)
				{
					displaySearchReport(userName, currentInventory.getSearchCount(), currentInventory.getSearchesFound(), currentInventory.getSearchesNotFound());
				}
					
			}//end of else
			menuSelection = validateMenuSelection(input);
			
		}//end of while
		
		if(currentInventory.getFileCount() > 0)
		{
			displayFileReport(userName, currentInventory.getFileCount(), currentInventory.getFilesFound(), currentInventory.getFilesNotFound());
		}
		
		//DISPLAY farewell message
		displayFarewellMessage();
		
		//close Scanner
		input.close();
	}//end of main method
	
	//Welcome banner
	public static void displayWelcomeBanner() 
	{
		System.out.println("******************************************");
		System.out.println("welcome to the local video store website");
		System.out.println("this site will let you import record fields");
		System.out.println("from a file, and enter the ID number");
		System.out.println("and shows the title and prices for the movie.");
		System.out.println("******************************************");
	}//End of display method
	
	//requests userName from user
	//return to main
	public static String getUserName(Scanner borrowedInput) 
	{
		String localUsrName = "";
		System.out.println("Please enter your name");
		localUsrName = borrowedInput.nextLine();
		return localUsrName;
	}//End of prompt

	public static char validateMenuSelection(Scanner borrowedInput)
	{
		char localMenuSelection = ' ';
		//Main Menu
		displayMainMenu();
		localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);

		while(localMenuSelection != 'A' && localMenuSelection != 'Q') 
		{
			System.out.println("\nInvalid Selection please try again.\n");
			displayMainMenu();
			localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return localMenuSelection;
	}
	public static void displayMainMenu() 
	{
		System.out.println("MAIN MENU");
		System.out.println("[A] for " +MAIN_MENU_OPTIONS[1]);
		System.out.println("[Q] for " +MAIN_MENU_OPTIONS[0]);
		System.out.println("Enter your selection here");

	}//end of Display method
	
	public static char validateSearchSelection(Scanner borrowedInput)
	{
		char localMenuSelection = ' ';
		//Main Menu
		displaySearchMenu();
		localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);

		while(localMenuSelection != 'A' && localMenuSelection != 'B') 
		{
			System.out.println("\nInvalid Selection please try again.\n");
			displaySearchMenu();
			localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return localMenuSelection;
	}
	public static void displaySearchMenu() 
	{
		System.out.println("");
		System.out.println("SEARCH MENU");
		System.out.println("[A] for " +SEARCH_MENU_OPTIONS[1]);
		System.out.println("[B] for " +SEARCH_MENU_OPTIONS[0]);
		System.out.println("Enter your selection here");

	}//end of Display method
	
	public static String getFileName(Scanner borrowedInput)
	{
		//declare local variables
		String localFileName = "";
		System.out.println("");
		System.out.println("Input the file Name for the product records:");
		localFileName = borrowedInput.next();

		return localFileName;
	}//end of getFileName
	
	public static int validateSearchID(Scanner borrowedInput) 
	{
		int localItem = 0;

		System.out.println("Input the Item ID# to search:");
		localItem = borrowedInput.nextInt();

		return localItem;
	}	
	
	public static void displayFileError()
	{
		System.out.println("File Not Found");
		System.out.println("Please try and check the file name again.");
	}
	
	public static void displaySearchResult()
	{
		System.out.println("SEARCH RESULT REPORT");
		System.out.println("ID not Found");
	}
	
	public static void displaySearchResult(int borrowedSearched, int[] borrowedID, String[] borrowedTitle, double[] borrowedPrice)
	{	
		
		System.out.println("SEARCH RESULTS REPORT");
		System.out.printf("%-10s%-13s%-1s\n","ITEM ID","TITLE","PRICE");
		System.out.printf("%-1s%-1s%-6s%-1s%-1s%-6s%-2s%-1s%-1s%-1s\n","[",borrowedID[borrowedSearched],"]","[",borrowedTitle[borrowedSearched],"]","$","[",borrowedPrice[borrowedSearched],"]");
		
	}
	
	public static void displayFarewellMessage()
	{
		System.out.println("Thank you for using the video store");
		System.out.println("website. We hope you have a nice day!");
	}
	
	public static void displaySearchReport(String borrowedUserName, int borrowedSearch, int borrowedSearchFound, int borrowedSearchNot)
	{
		System.out.printf("%-18s%-2s%8s\n","Customer's Name:","",borrowedUserName);
		System.out.println("SEARCH COUNT REPORT");
		System.out.printf("%-15s%-17s%-1s\n","SEARCH COUNT","IDs FOUND","IDs NOT FOUND");
		System.out.printf("%-1s%-1s%-13s%-1s%-1s%-15s%-1s%-1s%-1s\n","[",borrowedSearch,"]","[",borrowedSearchFound,"]","[",borrowedSearchNot,"]");
		
	}
	
	public static void displayFileReport(String borrowedUserName, int borrowedFile, int borrowedFileFound, int borrowedFileNot)
	{
		System.out.printf("%-18s%-2s%8s\n","Customer's Name:","",borrowedUserName);
		System.out.println("FILE PROCESSING REPORT");
		System.out.printf("%-15s%-17s%-1s\n","FILE COUNT","FILEs FOUND","FILEs NOT FOUND");
		System.out.printf("%-1s%-1s%-13s%-1s%-1s%-13s%-1s%-1s%-1s\n","[",borrowedFile,"]","[",borrowedFileFound,"]","[",borrowedFileNot,"]");
		
	}
}
