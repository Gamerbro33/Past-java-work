//AUTHOR: Robert Allen
//COURSE: CPT 187
//Purpose: Supports the main class for tracking inventory for local video store
//DATE: February 12 2020
package edu.cpt187.allen.program5;

import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
public class ProductInventory 
{
	//declare and initialize class CONSTANTS
	//constants are REQUIRED with object attributes
	private final int RESET = 0;
	private final int NOT_FOUND = -1;
	private final int MAXIMUM_RECORDS = 50;
	
	//declare and initialize all nonCONSTANTS class attributes
	private int[] productIDs = new int [MAXIMUM_RECORDS];
	private String[] productTitles = new String [MAXIMUM_RECORDS];
	private double[] productPrices = new double [MAXIMUM_RECORDS];
	private int recordCount = 0;
	private int searchedIndex = 0;
	private int fileCount = 0;
	private int filesFound = 0;
	private int fileNotFound = 0;
	private int searchCount = 0;
	private int searchesFound = 0;
	private int searchesNotFound = 0;
	
	//ProductInventory class constructor
	public ProductInventory()
	{
	}//END of class constructor
	
	//set method 
	//used file handling to assign values from files
	public void setProductArrays(String borrowedFileName)
	{
		recordCount = RESET;
		searchCount = RESET;
		searchesFound = RESET;
		fileCount++;
		
		try
		{
			Scanner infile = new Scanner(new FileInputStream(borrowedFileName));
			
			while(infile.hasNext() == true && recordCount < MAXIMUM_RECORDS)
			{
				productIDs[recordCount] = infile.nextInt();
				productTitles[recordCount] = infile.next();
				productPrices[recordCount] = infile.nextDouble();
				recordCount++;
				filesFound++;
			}//end of while
			
			infile.close();
		}//end of try
		
		catch(IOException ex)
		{
			recordCount = NOT_FOUND;
			fileNotFound++;
		}
	}//end of setProductArrays
	
	//set method
	public void setSearchIndex(int borrowedID)
	{
		searchCount++;
		searchedIndex = getSeqSearch(borrowedID);
		if(searchedIndex > NOT_FOUND)
		{
			searchesFound++;
		}
		else
		{
			searchesNotFound++;
		}
	}//end of setSearchIndex
	
	//get method
	public int getSeqSearch(int borrowedTarget)
	{
		int localIndex = 0;
		int found = NOT_FOUND;
		
		while(localIndex < recordCount)
		{
			if(borrowedTarget == productIDs[localIndex])
			{
				found = localIndex;
				localIndex = recordCount;
			}
			else
			{
				localIndex++;
			}
		}

		return found;
	}//end of getSeqSearch
	
	//get method
	//method that will return searchedIndex
	public int getSearchedIndex()
	{
		return searchedIndex;
	}//end of getSearchedIndex
	
	//get method
	//method that will return recordCount
	public int getRecordCount()
	{
		return recordCount;
	}//end of getRecordCount
	
	//get method
	//method that will return productID
	public int[] getProductID()
	{
		return productIDs;
	}//end of getProductID
	
	//get method
	//method that will return productTitle
	public String[] getProductTitle()
	{
		return productTitles;
	}//end of getProductTitles
	
	//get method
	//method that will return productPrices
	public double[] getProductPrice()
	{
		return productPrices;
	}//end of getProductPrice
	
	//get method
	//method that will return fileCount
	public int getFileCount()
	{
		return fileCount;
	}//end of getFileCount
	
	//get method
	//method that will return fileFound
	public int getFilesFound()
	{
		return filesFound;
	}//end of getFileFound
	
	//get method
	//method that will return NOT_FOUND
	public int getFilesNotFound()
	{
		return fileNotFound;
	}//end of getFileCount
	
	//get method
	//method that will return searchCount
	public int getSearchCount()
	{
		return searchCount;
	}//end of getSearchCount
	
	//get method
	//method that will return searchFound
	public int getSearchesFound()
	{
		return searchesFound;
	}//end of getSearchFound
	
	//get method
	//method that will return NOT_FOUND
	public int getSearchesNotFound()
	{
		return searchesNotFound;
	}//end of getSeachesNotFound
}
