//AUTHOR: Robert Allen
//COURSE: CPT 187
//Purpose: to help a local Video Store for DVDs that will keep track of the inventory
//DATE: February 19 2020
package edu.cpt187.allen.program6;


import java.util.Scanner;


public class MainClass 
{
	public static final String[] MAIN_MENU_OPTIONS = {"Quit","Load Product Catalog"};
	public static final String[] SEARCH_MENU_OPTIONS = {"Return to Main Menu","Search for an ID"};

	public static final String[] PURCHASE_MENU_OPTIONS = {"Purchase copies of the DVD","Return to the Search Menu"};
	public static final String MASTER_FILE_NAME = "MasterOrderFile.txt";		

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);

		//local variables 
		String userName = "";
		char menuSelection = ' ';

		//Create instance from the supportive class 
		ProductInventory currentInventory = new ProductInventory();

		WritePurchaseOrders purchaseOrder = new WritePurchaseOrders(MASTER_FILE_NAME);
		//DISPLAY Welcome Banner
		displayWelcomeBanner();


		//gets and displays userName
		userName = getUserName(input);

		//Prime read of MenuSelection
		menuSelection = validateMenuSelection(input);

		//run-while
		while(menuSelection != 'Q')
		{
			currentInventory.setProductArrays(getFileName(input));

			//run if else
			if(currentInventory.getRecordCount() <= 0)
			{
				displayFileError();
			}//end of if
			else
			{
				menuSelection = validateSearchSelection(input);

				while(menuSelection != 'B')
				{
					currentInventory.setSearchIndex(validateSearchID(input));
					if(currentInventory.getSearchedIndex() < 0)
					{
						displaySearchResult();
					}
					else
					{
						displaySearchResult(currentInventory.getProductID(), currentInventory.getProductTitles(), currentInventory.getProductPrice());


						//display and input purchase menu
						menuSelection = validatePurchaseSelection(input);
						if(menuSelection == 'A')
						{
							
							currentInventory.setHowMany(validateHowMany(input));
							currentInventory.getOrderQuantitys();
							//records the inputs into the master file
							purchaseOrder.setWriteOneRecord(currentInventory.getProductID(), currentInventory.getProductTitles(), currentInventory.getProductPrice(), currentInventory.getHowMany(), currentInventory.getTotalCost());
							displayPurchaseReport(currentInventory.getProductID(), currentInventory.getHowMany(), currentInventory.getTotalCost());
							
						}//end of if
					}//end of else
					menuSelection = validateSearchSelection(input);

				}//end of while

				if(currentInventory.getSearchCount() > 0)
				{
					displaySearchReport(userName, currentInventory.getSearchCount(), currentInventory.getSearchesFound(), currentInventory.getSearchesNotFound());
				}//end of if

			}//end of else
			menuSelection = validateMenuSelection(input);

		}//end of while

		if(currentInventory.getFileCount() > 0)
		{
			displayFileReport(userName, currentInventory.getFileCount(), currentInventory.getFilesFound(), currentInventory.getFilesNotFound());
			if(purchaseOrder.getRecordCount() > 0)
			{
				currentInventory.setProductArrays(purchaseOrder.getFileName(), currentInventory.getRecordCount());
				displayOrderReport(currentInventory.getRecordCount(), currentInventory.getProductIDs(), currentInventory.getProductTitless(), currentInventory.getProductPrices(), currentInventory.getOrderQuantitys(), currentInventory.getOrderTotals(), currentInventory.getWrittenOrderTotalCost(), currentInventory.getWrittenOrderQuantity());
			}
		
		}
		

		//DISPLAY farewell message
		displayFarewellMessage();

		//close Scanner
		input.close();
	}//end of main method

	//Welcome banner
	public static void displayWelcomeBanner() 
	{
		System.out.println("******************************************");
		System.out.println("welcome to the local video store website");
		System.out.println("this site will let you import record fields");
		System.out.println("from a file, and enter the ID number");
		System.out.println("and shows the title and prices for the movie.");
		System.out.println("******************************************");
	}//End of display method

	//requests userName from user
	//return to main
	public static String getUserName(Scanner borrowedInput) 
	{
		String localUsrName = "";
		System.out.println("Please enter your name");
		localUsrName = borrowedInput.nextLine();
		return localUsrName;
	}//End of prompt

	public static char validateMenuSelection(Scanner borrowedInput)
	{
		char localMenuSelection = ' ';
		//Main Menu
		displayMainMenu();
		localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);

		while(localMenuSelection != 'A' && localMenuSelection != 'Q') 
		{
			System.out.println("\nInvalid Selection please try again.\n");
			displayMainMenu();
			localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return localMenuSelection;
	}
	public static void displayMainMenu() 
	{
		System.out.println("MAIN MENU");
		System.out.println("[A] for " +MAIN_MENU_OPTIONS[1]);
		System.out.println("[Q] for " +MAIN_MENU_OPTIONS[0]);
		System.out.println("Enter your selection here");

	}//end of Display method

	public static char validateSearchSelection(Scanner borrowedInput)
	{
		char localMenuSelection = ' ';
		//Main Menu
		displaySearchMenu();
		localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);

		while(localMenuSelection != 'A' && localMenuSelection != 'B') 
		{
			System.out.println("\nInvalid Selection please try again.\n");
			displaySearchMenu();
			localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return localMenuSelection;
	}
	public static void displaySearchMenu() 
	{
		System.out.println("");
		System.out.println("SEARCH MENU");
		System.out.println("[A] for " +SEARCH_MENU_OPTIONS[1]);
		System.out.println("[B] for " +SEARCH_MENU_OPTIONS[0]);
		System.out.println("Enter your selection here");

	}//end of Display method

	public static void displayPurchaseMenu() 
	{
		System.out.println("");
		System.out.println("PURCHASE MENU");
		System.out.println("[A] for " +PURCHASE_MENU_OPTIONS[0]);
		System.out.println("[B] for " +PURCHASE_MENU_OPTIONS[1]);
		System.out.println("Enter your selection here");

	}//end of Display method

	public static char validatePurchaseSelection(Scanner borrowedInput)
	{
		char localMenuSelection = ' ';
		//Main Menu
		displayPurchaseMenu();
		localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);

		while(localMenuSelection != 'A' && localMenuSelection != 'B') 
		{
			System.out.println("\nInvalid Selection please try again.\n");
			displayPurchaseMenu();
			localMenuSelection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return localMenuSelection;
	}

	public static String getFileName(Scanner borrowedInput)
	{
		//declare local variables
		String localFileName = "";
		System.out.println("");
		System.out.println("Input the file Name for the product records:");
		localFileName = borrowedInput.next();

		return localFileName;
	}//end of getFileName

	//display howMany question
	public static void displayHowMany() 
	{
		System.out.println("How many of this product would you like");
	}
	//user input HowMany
	public static int validateHowMany(Scanner borrowedInput)
	{
		int localHowMany = 0;
		displayHowMany();
		localHowMany = borrowedInput.nextInt();
		//validate input

		while(localHowMany <= 0) 
		{
			System.out.println("Please choose a quantity greater than ZERO");
			displayHowMany();
			localHowMany = borrowedInput.nextInt();
		}
		return localHowMany;
	}//end of howMany VR Method

	//display purchase report
	public static void displayPurchaseReport(int borrowedID, int borrowedHowMany, double borrowedTotal)
	{
	 System.out.println("REQUEST CONFIRMATION");
	 System.out.println("");
	 System.out.printf("%-10s%-7s%-1s","ITEM ID","QTY","TOTAL");
	 System.out.println("");
	 System.out.printf("%-2s%-3s%-6s%-1s%-1s%-5s%-2s%-1.2f%-1s","[",borrowedID,"]","[",borrowedHowMany,"]","$[",borrowedTotal,"]");
	 System.out.println("");
	 System.out.println("records have been Updated");
	}
	//validate Search ID
	public static int validateSearchID(Scanner borrowedInput) 
	{
		int localItem = 0;

		System.out.println("Input the Item ID# to search:");
		localItem = borrowedInput.nextInt();

		//validate input

		while(localItem <= 0) 
		{
			System.out.println("Please enter the numbers greater than ZERO");
			System.out.println("");
			System.out.println("Input the Item ID# to search:");
			localItem = borrowedInput.nextInt();
		}
		return localItem;
	}	


	//display File error
	public static void displayFileError()
	{
		System.out.println("File Not Found");
		System.out.println("Please try and check the file name again.");
	}

	//display error Search Result
	public static void displaySearchResult()
	{
		System.out.println("SEARCH RESULT REPORT");
		System.out.println("ID not Found");
	}

	//display search Result
	public static void displaySearchResult(int borrowedID, String borrowedTitle, double borrowedPrice)
	{	

		System.out.println("SEARCH RESULTS REPORT");
		System.out.printf("%-10s%-13s%-1s","ITEM ID","TITLE","PRICE");
		System.out.println("");
		System.out.printf("%-1s%-1s%-6s%-1s%-1s%-6s%-2s%-1s%-1s%-1s","[",borrowedID,"]","[",borrowedTitle,"]","$","[",borrowedPrice,"]");

	}


	//displayFarewellMessage
	public static void displayFarewellMessage()
	{
		System.out.println("");
		System.out.println("Thank you for using the video store");
		System.out.println("website. We hope you have a nice day!");
	}


	//display Search Report
	public static void displaySearchReport(String borrowedUserName, int borrowedSearch, int borrowedSearchFound, int borrowedSearchNot)
	{
		System.out.printf("%-18s%-2s%8s\n","Customer's Name:","",borrowedUserName);
		System.out.println("SEARCH COUNT REPORT");
		System.out.printf("%-15s%-17s%-1s\n","SEARCH COUNT","IDs FOUND","IDs NOT FOUND");
		System.out.printf("%-1s%-1s%-13s%-1s%-1s%-15s%-1s%-1s%-1s\n","[",borrowedSearch,"]","[",borrowedSearchFound,"]","[",borrowedSearchNot,"]");

	}
	//display Order report
	public static void displayOrderReport(int borrowedRecordCount, int[] borrowedID, String[] borrowedTitle, double[] borrowedPrice, int[] borrowedQty, double[] borrowedTotal,  double borrowedTotalCost, int borrowedWrittenQty)
	{	

		int localIndex = 0;
		System.out.println("SEARCH RESULTS REPORT");
		System.out.printf("%-10s%-13s%-11s%-6s%-1s\n","ITEM ID","TITLE","PRICE","QTY","TOTAL");
		while (localIndex < borrowedRecordCount)
		{
			if(borrowedTitle[localIndex] != null)
			{
				System.out.printf("%-1s%-1s%-6s%-1s%-1s%-6s%-2s%-1s%-3s%-1s%-1s%-4s%-2s%-4s%-1s\n","[",borrowedID[localIndex],"]","[",borrowedTitle[localIndex],"]","$ [",borrowedPrice[localIndex],"]","[",borrowedQty[localIndex],"]","$[",borrowedTotal[localIndex],"]");
			}
			localIndex++;
		}
		System.out.printf("%-17s%-1s","ITEM COUNT","ORDER TOTAL");
		System.out.println("");
		System.out.printf("%-2s%-2s%-13s%-2s%-4.2f%-1s","[",borrowedWrittenQty,"]","$[",borrowedTotalCost,"]");
	}


	//display final report
	public static void displayFileReport(String borrowedUserName, int borrowedFile, int borrowedFileFound, int borrowedFileNot)
	{
		System.out.printf("%-18s%-2s%8s\n","Customer's Name:","",borrowedUserName);
		System.out.println("FILE PROCESSING REPORT");
		System.out.printf("%-15s%-17s%-1s\n","FILE COUNT","FILEs FOUND","FILEs NOT FOUND");
		System.out.printf("%-1s%-1s%-13s%-1s%-1s%-13s%-1s%-1s%-1s\n","[",borrowedFile,"]","[",borrowedFileFound,"]","[",borrowedFileNot,"]");

	}
}


