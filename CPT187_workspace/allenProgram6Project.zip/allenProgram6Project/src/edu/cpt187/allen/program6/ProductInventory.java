//AUTHOR: Robert Allen
//COURSE: CPT 187
//Purpose: Supports the main class for tracking inventory for local video store
//DATE: February 19 2020
package edu.cpt187.allen.program6;

import java.util.Arrays;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;


public class ProductInventory 
{
	//declare and initialize class CONSTANTS
	//constants are REQUIRED with object attributes
	private final int RESET = 0;
	private final int NOT_FOUND = -1;
	private final int MAXIMUM_RECORDS = 50;
	
	//declare and initialize all nonCONSTANTS class attributes
	private int[] productIDs = new int [MAXIMUM_RECORDS];
	private String[] productTitles = new String [MAXIMUM_RECORDS];
	private double[] productPrices = new double [MAXIMUM_RECORDS];
	private int[] orderQuantity = new int [MAXIMUM_RECORDS];
	private double[] orderTotal = new double [MAXIMUM_RECORDS];
	private int recordCount = 0;
	private int searchedIndex = 0;
	private int howMany = 0;
	private int fileCount = 0;
	private int filesFound = 0;
	private int searchCount = 0;
	private int searchesFound = 0;
	
	//ProductInventory class constructor
	public ProductInventory()
	{
	}//END of class constructor
	
	//set method 
	//used file handling to assign values from files
	public void setProductArrays(String borrowedFileName)
	{
		recordCount = RESET;
		searchCount = RESET;
		searchesFound = RESET;
		fileCount++;

		try
		{
			Scanner infile = new Scanner(new FileInputStream(borrowedFileName));

			while(infile.hasNext() == true && recordCount < MAXIMUM_RECORDS)
			{
				productIDs[recordCount] = infile.nextInt();
				productTitles[recordCount] = infile.next();
				productPrices[recordCount] = infile.nextDouble();
				recordCount++;
				filesFound++;
			}//end of while

			//close file
			infile.close();
			
			//set
			setBubbleSort();
		}//end of try

		catch(IOException ex)
		{
			recordCount = NOT_FOUND;
		}
	}//end of setProductArrays
	
	//set method
	public void setProductArrays(String borrowedFileName, int borrowedSize)
	{
		recordCount = RESET;
		searchCount = RESET;
		searchesFound = RESET;
		orderQuantity = new int[borrowedSize];
		orderTotal = new double[borrowedSize];
		fileCount++;
		
		
		try
		{
			Scanner infile = new Scanner(new FileInputStream(borrowedFileName));
			while(infile.hasNext() == true && recordCount < borrowedSize)
			{
				productIDs[recordCount] = infile.nextInt();
				productTitles[recordCount] = infile.next();
				productPrices[recordCount] = infile.nextDouble();
				orderQuantity[recordCount] = infile.nextInt();
				orderTotal[recordCount] = infile.nextDouble();
				recordCount++;
				filesFound++;
			}//end of while
			//close the file
			infile.close();
			//sort
			setBubbleSort();
		}//end of try
		catch(IOException ex)
		{
			recordCount = NOT_FOUND;
		}//end of catch
	}//end of setProductArrays

	//set method
	public void setSearchIndex(int borrowedID)
	{
		searchCount++;
		searchedIndex = getBinSearch(borrowedID);
		if(searchedIndex > NOT_FOUND)
		{
			searchesFound++;
		}//end of if
	}//end of setSearchIndex
	
	//set method
	public void setHowMany(int borrowedHowMany)
	{
		howMany = borrowedHowMany;
	}//end of setHowMany
	
	//set method
	public void setBubbleSort()
	{
		int last = 0;
		int index = 0;
		boolean swap;

		last = recordCount - 1;

		while(last > RESET)
		{
			index = RESET;
			swap = false;

			while(index < last)
			{
				if (productIDs[index] > productIDs[index + 1])
				{
					setSwapArrayElements(index);
					swap = true;
				}//end of if

				index++;
			}//end of while

			if (swap == false)
			{
				last = RESET;
			}
			else
			{
				last = last - 1;
			}
		}//end of while

	}//end of setBubbleSort

	//set method
		public void setSwapArrayElements(int borrowedIndex)
		{
			int localIntHolder = 0;
			String localStringHolder = "";
			double localDoubleHolder = 0.0;
			
			//item ID
			localIntHolder = productIDs[borrowedIndex + 1];
			productIDs[borrowedIndex + 1] = productIDs[borrowedIndex];
			productIDs[borrowedIndex] = localIntHolder;
			
			//Item name
			localStringHolder = productTitles[borrowedIndex + 1];
			productTitles[borrowedIndex + 1] = productTitles[borrowedIndex];
			productTitles[borrowedIndex] = localStringHolder;
					
			//item price
			localDoubleHolder = productPrices[borrowedIndex + 1];
			productPrices[borrowedIndex + 1] = productPrices[borrowedIndex];
			productPrices[borrowedIndex] = localDoubleHolder;
			
			
		
		}//end of setSwapArrayElements
		
	//get method
	public int getBinSearch(int borrowedBorrowedID)
	{
		int first = 0;
		int last = 0;
		int mid = 0;
		boolean found;
		
		last = recordCount - 1;
		found = false;

		while(first <= last && found == false)
		{
			mid = (first + last) / 2;
			
			if (productIDs[mid] == borrowedBorrowedID)
			{
				found = true;
			}
			else
			{
				if(productIDs[mid] < borrowedBorrowedID)
				{
					first = mid + 1;
				}
				else
				{
					last = mid - 1;
				}
			}
			
		}//end of while
		if(found == false)
		{
			mid = NOT_FOUND;
		}

		return mid;
	}//end of getBinSearch
	
	//get method
	//method that return the value for howMany
	public int getHowMany()
	{
		return howMany;
	}//end of getHowMany
	
	//get method
	//method that will return productID
	public int getProductID()
	{
		return productIDs[searchedIndex];
	}//end of getProductID

	//get method
	//method that will return productTitle
	public String getProductTitles()
	{
		return productTitles[searchedIndex];
	}//end of getProductTitles

	//get method
	//method that will return productPrices
	public double getProductPrice()
	{	
		return productPrices[searchedIndex];
	}//end of getProductPrice
	
	//get method
	//method that will return productID
	public int[] getProductIDs()
	{
		return productIDs;
	}//end of getProductID

	//get method
	//method that will return productTitle
	public String[] getProductTitless()
	{
		return productTitles;
	}//end of getProductTitles

	//get method
	//method that will return productPrices
	public double[] getProductPrices()
	{
		return productPrices;
	}//end of getProductPrice
	
	//get method
	//method that will return orderQuantity
	public int[] getOrderQuantitys()
	{
		return orderQuantity;
	}//end of getOrderQuantity
	
	//get method 
	//method that returns the value of orderTotal
	public double[] getOrderTotals()
	{
		return orderTotal;
	}//end of getOrderTotal
		
	//get method
	//method that will return fileCount
	public int getFileCount()
	{
		return fileCount;
	}//end of getFileCount

	//get method
	//method that will return fileFound
	public int getFilesFound()
	{
		return filesFound;
	}//end of getFileFound

	//get method
	public int getFilesNotFound()
	{
		return filesFound - fileCount;
	}//end of getFileCount

	//get method
	//method that will return searchedIndex
	public int getSearchedIndex()
	{
		return searchedIndex;
	}//end of getSearchedIndex

	//get method
	//method that will return recordCount
	public int getRecordCount()
	{
		return recordCount;
	}//end of getRecordCount

	//get method
	//method that will return searchCount
	public int getSearchCount()
	{
		return searchCount;
	}//end of getSearchCount

	//get method
	//method that will return searchFound
	public int getSearchesFound()
	{
		return searchesFound;
	}//end of getSearchFound

	//get method
	public int getSearchesNotFound()
	{
		return searchCount - searchesFound;
	}//end of getSeachesNotFound

	//get method 
	public double getTotalCost()
	{
		return getProductPrice() * getHowMany(); 
	}//end of getTotalCost
	
	//get method
	public int getWrittenOrderQuantity()
	{
		return Arrays.stream(orderQuantity).sum();
	}//end of getWrittenQuantity
	
	//get method
	public double getWrittenOrderTotalCost()
	{
	
		return Arrays.stream(orderTotal).sum();
		
	}//end of getWrittenOrderTotalCost
	
}
