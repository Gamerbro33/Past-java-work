//AUTHOR: Robert Allen
//COURSE: CPT 187
//Purpose: Supports the main class for for purchases details in the correct order
//DATE: February 19 2020
package edu.cpt187.allen.program6;

import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WritePurchaseOrders 
{
	//declare and initialize class CONSTANTS
	//constants are REQUIRED with object attributes
	private final int FAILED_VALUE = -1;
	private final int RESET_VALUE = 0;
	
	//declare and initialize all nonCONSTANTS class attributes
	private String masterFileName = "";
	private boolean fileFoundFlag;
	private int recordCount = 0;
	
	//WritePurchaseOrder class constructor
	public WritePurchaseOrders(String borrowedFileName)
	{
		masterFileName = borrowedFileName;
	}//end of class constructor
	
	//set method
	public void setWriteOneRecord(int borrowedID, String borrowedTitle, double borrowedPrice, int borrowedQty, double borrowedTotal)
	{
		recordCount = RESET_VALUE;
		try
		{
			PrintWriter filePW = new PrintWriter (new FileWriter(masterFileName, true));
			filePW.printf("%d\t%s\t%f\t%d\t%f\r", borrowedID, borrowedTitle, borrowedPrice, borrowedQty, borrowedTotal);
			fileFoundFlag = true;
			recordCount++;
			//close the file
			filePW.close();
		}//END of try
		catch(IOException ex)
		{
			recordCount = FAILED_VALUE;
			fileFoundFlag = false;
		}//END of catch 
	}//end of setWriteOneRecord
	
	//get method
	// this method return the value of masterFileName
	public String getFileName()
	{
		return masterFileName;
	}//end of getFileName
	
	//get method
	//this method return the value of fileFoundFlag
	public boolean getFileFoundFlag()
	{
		return fileFoundFlag;
	}//end of getfileFoundFlag
	
	//get method 
	//method that return the value of recordCount
	public int getRecordCount()
	{
		return recordCount;
	}//end of getRecorCount
}
